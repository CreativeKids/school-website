#!/bin/bash
rm -rf assets/static/swf
rm -rf src/scratch-flash/build
rm -rf assets/static/project-gallery.zip
