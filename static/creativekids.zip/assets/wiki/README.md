[![Build Status](https://travis-ci.org/rhysmoyne/creative-kids-dokuwiki.svg?branch=master)](https://travis-ci.org/rhysmoyne/creative-kids-dokuwiki)

All documentation for DokuWiki is available online
at http://www.dokuwiki.org/

For Installation Instructions see
http://www.dokuwiki.org/install

DokuWiki - 2004-2016 (c) Andreas Gohr <andi@splitbrain.org>
                         and the DokuWiki Community
See COPYING and file headers for license info

Admin username: admin
Admin password: ckadmin123

