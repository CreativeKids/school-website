# OpenSprites fork of scratch-flash #

To be used on [OpenSprites-next](https://github.com/OpenSprites/OpenSprites-next).

For more info on Scratch, see [the readme](https://github.com/LLK/scratch-flash#scratch-20-editor-and-player-)